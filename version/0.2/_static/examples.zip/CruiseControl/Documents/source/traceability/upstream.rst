Upstream - downstream
=====================

.. needtable::
    :types: hlr
    :sort: id
    :columns: id,title,covers_back
    :style: datatable
