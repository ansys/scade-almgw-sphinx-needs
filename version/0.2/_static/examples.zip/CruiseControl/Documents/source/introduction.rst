Introduction
============

The Cruise control is a system to automatically control the speed of a car.
The driver sets the speed, and the system will take over the throttle of the car to maintain the same speed.
