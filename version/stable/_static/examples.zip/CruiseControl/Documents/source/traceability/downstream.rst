Downstream - upstream
=====================

.. needtable::
    :types: llr
    :sort: id
    :columns: id,title,covers
    :style: datatable
