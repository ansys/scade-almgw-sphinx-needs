Pedals pressed detection
========================

.. hlr:: Accelerator
   :id: CC_HLR_PPD_01
   :collapse: true

   The accelerator pedal shall be detected as pressed when its value is above ``PEDALS_MIN``.

.. hlr:: Brake
   :id: CC_HLR_PPD_02
   :collapse: true

   The brake pedal shall be detected as pressed when its value is above ``PEDALS_MIN``.
