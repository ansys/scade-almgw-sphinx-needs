Design
======

.. needimport:: /_scade/model.json
    :layout: scade-suite
    :template: llr
